package com.tvhub.kitkat;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String HOME_URL = "file:///android_asset/index.html?native=1";
    private WebView webView;
    private DownloadManager downloadManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);

        webView = new WebView(this);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        webView.setBackgroundColor(0xff0b1220);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadsImagesAutomatically(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url != null && url.startsWith("tvhub://")) {
                    handleHubAction(Uri.parse(url));
                    return true;
                }
                if (url != null && (url.startsWith("https://") || url.startsWith("http://") || url.startsWith("file:///android_asset/"))) {
                    return false;
                }
                return true;
            }
        });
        webView.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimeType, long contentLength) {
                enqueueDownload(url, contentDisposition, mimeType);
            }
        });

        setContentView(webView);
        webView.loadUrl(HOME_URL);
        webView.requestFocus();
    }

    private void handleHubAction(Uri uri) {
        String action = uri.getHost();
        if ("home".equals(action)) {
            webView.loadUrl(HOME_URL);
            return;
        }
        if ("downloads".equals(action)) {
            openDownloads();
            return;
        }
        String target = uri.getQueryParameter("url");
        if (!isSafeWebUrl(target)) {
            Toast.makeText(this, "Only valid HTTPS download links are allowed.", Toast.LENGTH_LONG).show();
            return;
        }
        if ("open".equals(action)) {
            webView.loadUrl(target);
        } else if ("download".equals(action)) {
            enqueueDownload(target, null, "application/vnd.android.package-archive");
        }
    }

    private boolean isSafeWebUrl(String value) {
        if (value == null) return false;
        Uri parsed = Uri.parse(value);
        return "https".equalsIgnoreCase(parsed.getScheme()) && parsed.getHost() != null;
    }

    private void enqueueDownload(String url, String contentDisposition, String mimeType) {
        if (!isSafeWebUrl(url)) {
            Toast.makeText(this, "Blocked a non-HTTPS download link.", Toast.LENGTH_LONG).show();
            return;
        }
        if (downloadManager == null) {
            Toast.makeText(this, "Android Download Manager is not available on this TV.", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            String fileName = URLUtil.guessFileName(url, contentDisposition, mimeType);
            if (fileName == null || fileName.length() == 0) fileName = "TVHub-download.apk";
            DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
            request.setTitle(fileName);
            request.setDescription("Downloading with TV App Hub");
            request.setMimeType(mimeType == null ? "application/octet-stream" : mimeType);
            request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE);
            request.setAllowedOverRoaming(false);
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
            downloadManager.enqueue(request);
            Toast.makeText(this, "Download started. Check the Downloads screen when it finishes.", Toast.LENGTH_LONG).show();
        } catch (Exception ex) {
            Toast.makeText(this, "Could not start download: " + ex.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void openDownloads() {
        try {
            Intent intent = new Intent(DownloadManager.ACTION_VIEW_DOWNLOADS);
            startActivity(intent);
        } catch (ActivityNotFoundException ex) {
            Toast.makeText(this, "Open the TV's Downloads app to view APK files.", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        // The HTML page handles all four D-pad directions and the Select/OK key.
        if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
            return webView.dispatchKeyEvent(event) || super.onKeyDown(keyCode, event);
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
